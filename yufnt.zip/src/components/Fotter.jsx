import React from "react";

function Footer() {
  return (
    <footer>
      <p>Copyright by ShapeAI @ {new Data().getFullyear}
      </footer>
  );
}

export default Footer;